package ex01;

public abstract class GeometriaPlana extends Figura{

	abstract double perimetro();

}
