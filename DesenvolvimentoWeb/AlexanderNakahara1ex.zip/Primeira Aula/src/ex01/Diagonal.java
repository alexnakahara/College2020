package ex01;

public interface Diagonal {
	
	 double calcularDiagonal();
}
