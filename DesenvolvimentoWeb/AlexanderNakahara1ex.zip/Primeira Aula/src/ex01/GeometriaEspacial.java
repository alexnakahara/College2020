package ex01;

public abstract class GeometriaEspacial extends Figura{

	abstract double volume();

}
