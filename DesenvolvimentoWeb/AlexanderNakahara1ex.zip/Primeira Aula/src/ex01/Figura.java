package ex01;

public abstract class Figura {

	 abstract double area();
}

 